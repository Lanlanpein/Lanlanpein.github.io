"""
用线性回归预测房价数据
第十四组：
P12314008 刘昊辰
P12314080 丁梓翔
P12314012 张嘉诚
P12314016 罗天屹

分析目标：
此数据分析报告的目的是，基于已有的房屋销售价格，以及有关该房屋的属性，进行线性回归分析，从而利用得到的线性回归模型，能对以下未知售价的房屋根据属性进行价格预测：
面积为6500平方英尺，有4个卧室、2个厕所，总共2层，不位于主路，无客人房，带地下室，有热水器，没有空调，车位数为2，位于城市首选社区，简装修。

数据集简介：
price：房屋出售价格
area：房屋面积，以平方英尺为单位
bedrooms：卧室数
bathrooms：厕所数
stories：楼层数
mainroad：是否位于主路
guestroom：是否有客房
basement：是否有地下室
hotwaterheating：是否有热水器
airconditioning：是否有空调
parking：车库容量，以车辆数量为单位
prefarea：是否位于城市首选社区
furnishingstatus：装修状态（furnished 精装，semi-furnished简装unfurnished 毛坯）
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm

#读取数据
#导入数据分析所需要的库，并通过Pandas的read_csv函数，将原始数据文件"house_price.csv"里的数据内容，解析为DataFrame并赋值给变量original_house_price。
original_house_price = pd.read_csv("house_price.csv")
original_house_price.head()

#评估和清理数据
#在这一部分中，我们将对在上一部分建立的`original_house_price`DataFrame所包含的数据进行评估和清理。
#主要从两个方面进行：结构和内容，即整齐度和干净度。
#数据的结构性问题指不符合“每个变量为一列，每个观察值为一行，每种类型的观察单位为一个表格”这三个标准；数据的内容性问题包括存在丢失数据、重复数据、无效数据等。

cleaned_house_price = original_house_price.copy()
cleaned_house_price.head(10)
cleaned_house_price.info()

cleaned_house_price['mainroad'] = cleaned_house_price['mainroad'].astype("category")
cleaned_house_price['guestroom'] = cleaned_house_price['guestroom'].astype("category")
cleaned_house_price['basement'] = cleaned_house_price['basement'].astype("category")
cleaned_house_price['hotwaterheating'] = cleaned_house_price['hotwaterheating'].astype("category")
cleaned_house_price['airconditioning'] = cleaned_house_price['airconditioning'].astype("category")
cleaned_house_price['prefarea'] = cleaned_house_price['prefarea'].astype("category")
cleaned_house_price['furnishingstatus'] = cleaned_house_price['furnishingstatus'].astype("category")

cleaned_house_price.info()

cleaned_house_price["mainroad"].value_counts()
cleaned_house_price["guestroom"].value_counts()
cleaned_house_price["basement"].value_counts()
cleaned_house_price["hotwaterheating"].value_counts()
cleaned_house_price["airconditioning"].value_counts()
cleaned_house_price["prefarea"].value_counts()
cleaned_house_price["furnishingstatus"].value_counts()
cleaned_house_price.describe()


#探索数据
#在着手推断统计学分析之前，我们可以先借助数据可视化，探索数值变量的分布，以及与房价存在相关性的变量，为后续的进一步分析提供方向。

# 设置图表色盘为"pastel"
sns.set_palette("pastel")

#房价分布
plt.rcParams["figure.figsize"] = [7.00, 3.50]
plt.rcParams["figure.autolayout"] = True
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='price', ax=axes[0])
sns.boxplot(cleaned_house_price, y='price', ax=axes[1])
plt.show()

#面积分布
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='area', ax=axes[0])
sns.boxplot(cleaned_house_price, y='area', ax=axes[1])
plt.show()

#房价与面积的关系
sns.scatterplot(cleaned_house_price, x='area', y='price')
plt.show()

#卧室数与房价
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='bedrooms', ax=axes[0])
sns.barplot(cleaned_house_price, x='bedrooms', y='price', ax=axes[1])
plt.show()

#洗手间与房价
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='bathrooms', ax=axes[0])
sns.barplot(cleaned_house_price, x='bathrooms', y='price', ax=axes[1])
plt.show()

#楼层数与房价
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='stories', ax=axes[0])
sns.barplot(cleaned_house_price, x='stories', y='price', ax=axes[1])
plt.show()

#车库数与房价
figure, axes = plt.subplots(1, 2)
sns.histplot(cleaned_house_price, x='parking', ax=axes[0])
sns.barplot(cleaned_house_price, x='parking', y='price', ax=axes[1])
plt.show()

#是否在主路与房价
figure, axes = plt.subplots(1, 2)
mainroad_count = cleaned_house_price['mainroad'].value_counts()
mainroad_label = mainroad_count.index
axes[0].pie(mainroad_count, labels=mainroad_label)
sns.barplot(cleaned_house_price, x='mainroad', y='price', ax=axes[1])
plt.show()

#是否有客房与房价
figure, axes = plt.subplots(1, 2)
guestroom_count = cleaned_house_price['guestroom'].value_counts()
guestroom_label = guestroom_count.index
axes[0].pie(guestroom_count, labels=guestroom_label)
sns.barplot(cleaned_house_price, x='guestroom', y='price', ax=axes[1])
plt.show()

#是否有地下室与房价
figure, axes = plt.subplots(1, 2)
basement_count = cleaned_house_price['basement'].value_counts()
basement_label = basement_count.index
axes[0].pie(basement_count, labels=basement_label)
sns.barplot(cleaned_house_price, x='basement', y='price', ax=axes[1])
plt.show()

#是否有热水器与房价
figure, axes = plt.subplots(1, 2)
hotwaterheating_count = cleaned_house_price['hotwaterheating'].value_counts()
hotwaterheating_label = hotwaterheating_count.index
axes[0].pie(hotwaterheating_count, labels=hotwaterheating_label)
sns.barplot(cleaned_house_price, x='hotwaterheating', y='price', ax=axes[1])
plt.show()

#是否有空调与房价
figure, axes = plt.subplots(1, 2)
airconditioning_count = cleaned_house_price['airconditioning'].value_counts()
airconditioning_label = hotwaterheating_count.index
axes[0].pie(airconditioning_count, labels=airconditioning_label)
sns.barplot(cleaned_house_price, x='airconditioning', y='price', ax=axes[1])
plt.show()

#是否位于城市首选社区与房价
figure, axes = plt.subplots(1, 2)
prefarea_count = cleaned_house_price['prefarea'].value_counts()
prefarea_label = prefarea_count.index
axes[0].pie(prefarea_count, labels=prefarea_label)
sns.barplot(cleaned_house_price, x='prefarea', y='price', ax=axes[1])
plt.show()

#装修状态与房价
figure, axes = plt.subplots(1, 2)
furnishingstatus_count = cleaned_house_price['furnishingstatus'].value_counts()
furnishingstatus_label = furnishingstatus_count.index
axes[0].pie(furnishingstatus_count, labels=furnishingstatus_label)
sns.barplot(cleaned_house_price, x='furnishingstatus', y='price', ax=axes[1])
axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=45, horizontalalignment='right')
plt.show()

#用散点图大致查看相关性

#装修状态与各各数值变量
sns.pairplot(cleaned_house_price, hue="furnishingstatus", kind="reg")
plt.show()

#是否位于城市首选社区与各各数值变量
sns.pairplot(cleaned_house_price, hue="prefarea", kind="reg")
plt.show()

#是否有空调与各各数值变量
sns.pairplot(cleaned_house_price, hue="airconditioning", kind="reg")
plt.show()

#是否有热水器与各各数值变量
sns.pairplot(cleaned_house_price, hue="hotwaterheating", kind="reg")
plt.show()

#是否在主路与各各数值变量
sns.pairplot(cleaned_house_price, hue="mainroad", kind="reg")
plt.show()

#是否有客房与各各数值变量
sns.pairplot(cleaned_house_price, hue="guestroom", kind="reg")
plt.show()

#是否有地下室与各各数值变量
sns.pairplot(cleaned_house_price, hue="basement", kind="reg")
plt.show()

#模块三：相关性检验，使用t检验
#引入t检验所需模块
from scipy.stats import ttest_ind

#分析是否在主路与价格
sns.histplot(cleaned_house_price['price'], binwidth=0.1)
sns.histplot(cleaned_house_price['mainroad'], binwidth=0.1)
plt.show()

#建立假设
#H0：是否在主路与价格不存在显著区别。
#H1：是否在主路与价格存在显著区别。

#确定单尾检验还是双尾检验
#由于我们只检验平均值是否存在差异，不在乎哪个品种的萼片更长，所以是双尾检验。

#确定显著水平
#我们将选择0.05作为显著水平。

#计算t值和p值

t_stat, p_value = ttest_ind(cleaned_house_price["price"], cleaned_house_price["price"])
print(f"t值：{t_stat}")
print(f"p值：{p_value}")

#结论
#由于p值小于显著水平0.05，我们因此拒绝原假设，房价与是否在主路存在显著区别。


#分析是否在主路与价格
sns.histplot(cleaned_house_price['price'], binwidth=0.1)
sns.histplot(cleaned_house_price['guestroom'], binwidth=0.1)
plt.show()

#建立假设
#H0：是否在主路与价格不存在显著区别。
#H1：是否在主路与价格存在显著区别。

#确定单尾检验还是双尾检验
#由于我们只检验平均值是否存在差异，不在乎哪个品种的萼片更长，所以是双尾检验。

#确定显著水平
#我们将选择0.05作为显著水平。

#计算t值和p值

t_stat, p_value = ttest_ind(cleaned_house_price["price"], cleaned_house_price["price"])
print(f"t值：{t_stat}")
print(f"p值：{p_value}")

#结论
#由于p值小于显著水平0.05，我们因此拒绝原假设，房价与是否在主路存在显著区别。

#分析是否在主路与价格
sns.histplot(cleaned_house_price['price'], binwidth=0.1)
sns.histplot(cleaned_house_price['basement'], binwidth=0.1)
plt.show()

#建立假设
#H0：是否在主路与价格不存在显著区别。
#H1：是否在主路与价格存在显著区别。

#确定单尾检验还是双尾检验
#由于我们只检验平均值是否存在差异，不在乎哪个品种的萼片更长，所以是双尾检验。

#确定显著水平
#我们将选择0.05作为显著水平。

#计算t值和p值

t_stat, p_value = ttest_ind(cleaned_house_price["price"], cleaned_house_price["price"])
print(f"t值：{t_stat}")
print(f"p值：{p_value}")

#结论
#由于p值小于显著水平0.05，我们因此拒绝原假设，房价与是否在主路存在显著区别。


#分析是否在主路与价格
sns.histplot(cleaned_house_price['price'], binwidth=0.1)
sns.histplot(cleaned_house_price['hotwaterheating'], binwidth=0.1)
plt.show()

#建立假设
#H0：是否在主路与价格不存在显著区别。
#H1：是否在主路与价格存在显著区别。

#确定单尾检验还是双尾检验
#由于我们只检验平均值是否存在差异，不在乎哪个品种的萼片更长，所以是双尾检验。

#确定显著水平
#我们将选择0.05作为显著水平。

#计算t值和p值

t_stat, p_value = ttest_ind(cleaned_house_price["price"], cleaned_house_price["price"])
print(f"t值：{t_stat}")
print(f"p值：{p_value}")

#结论
#由于p值小于显著水平0.05，我们因此拒绝原假设，房价与是否在主路存在显著区别。


#分析是否在主路与价格
sns.histplot(cleaned_house_price['price'], binwidth=0.1)
sns.histplot(cleaned_house_price['airconditioning'], binwidth=0.1)
plt.show()

#建立假设
#H0：是否在主路与价格不存在显著区别。
#H1：是否在主路与价格存在显著区别。

#确定单尾检验还是双尾检验
#由于我们只检验平均值是否存在差异，不在乎哪个品种的萼片更长，所以是双尾检验。

#确定显著水平
#我们将选择0.05作为显著水平。

#计算t值和p值

t_stat, p_value = ttest_ind(cleaned_house_price["price"], cleaned_house_price["price"])
print(f"t值：{t_stat}")
print(f"p值：{p_value}")

#结论
#由于p值小于显著水平0.05，我们因此拒绝原假设，房价与是否在主路存在显著区别。



#分析数据
#在分析步骤中，我们将利用cleaned_house_price的数据，进行线性回归分析，目标是得到一个可以根据房屋各个属性对价格进行预测的数学模型。

lr_house_price = cleaned_house_price.copy()

lr_house_price = pd.get_dummies(lr_house_price, drop_first=True, columns=['mainroad', 'guestroom',
                                                         'basement', 'hotwaterheating',
                                                         'airconditioning','prefarea',
                                                         'furnishingstatus'], dtype=int)
lr_house_price

#接下来，我们要把因变量和自变量划分出来。
#因变量是price变量，因为我们进行线性回归的目的，是得到一个能根据其它可能对房屋价格有影响的变量，来预测销售价格的模型。
y = lr_house_price['price']

#我们可以把除价格之外的都纳入自变量，但需要查看它们之间的相关性。如果其中有些变量之间相关性很高，会导致共线性。
X = lr_house_price.drop('price', axis=1)

#用热力图检查共线性问题
sns.heatmap(X.corr().abs(), annot=True)
plt.plot()

#一般我们认为，当相关系数的绝对值大于0.8的时候，可能导致严重共线性，所以我们检查的时候，找绝对值大于0.8的值即可。
X.corr().abs() > 0.8

#给模型的线性方程添加截距。
X = sm.add_constant(X)
X

#调用OLS函数，利用最小二乘法来得到线性回归模型的参数值
model = sm.OLS(y, X).fit()

#查看模型结果，我们使用summary方法来获得总结信息。
model.summary()

#当我们把显著区间设定为0.05时，以上结果的P值可以看出，模型认为以下因素对房屋价格没有显著性影响：卧室数、是否为简装房。此外，常数（表示线性方程的截距）的P值也很大，说明也没有显著影响。
#可以把这些变量移除后，再次建立线性回归模型。
X = X.drop(['const', 'bedrooms', 'furnishingstatus_semi-furnished'], axis=1)
model = sm.OLS(y, X).fit()
model.summary()

#根据各个自变量在线性回归方程中的系数来看，模型预测以下因素的增加（或存在）会显著增加房屋价格：房屋面积、厕所数、楼层数、车库容量、位于主路、有客房、有地下室、有热水器、有空调、位于城市首选社区。
#线性回归模型预测以下因素的增加（或存在）会显著降低房屋价格：房屋未经装修，为毛坯房。
# 要预测房价的房屋的信息：
# 面积为6500平方英尺，有4个卧室、2个厕所，总共2层，不位于主路，无客人房，带地下室，有热水器，没有空调，车位数为2，位于城市首选社区，简装修
price_to_predict = pd.DataFrame({'area': [5600], 'bedrooms': [4], 'bathrooms': [2],
                                 'stories': [2], 'mainroad': ['no'], 'guestroom': ['no'],
                                 'basement': ['yes'], 'hotwaterheating': ['yes'],
                                 'airconditioning': ['no'], 'parking': 2, 'prefarea': ['yes'],
                                 'furnishingstatus': ['semi-furnished']})
price_to_predict

#把分类变量的类型转换为Category，并且通过categories参数，让程序知道所有可能的分类值。
#这样做的原因是，预测数据包含的分类可能不全。我们需要确保引入虚拟变量的时候，不会漏掉某个或某些分类。
price_to_predict['mainroad'] = pd.Categorical(price_to_predict['mainroad'], categories=['no', 'yes'])
price_to_predict['guestroom'] = pd.Categorical(price_to_predict['guestroom'], categories=['no', 'yes'])
price_to_predict['basement'] = pd.Categorical(price_to_predict['basement'], categories=['no', 'yes'])
price_to_predict['hotwaterheating'] = pd.Categorical(price_to_predict['hotwaterheating'], categories=['no', 'yes'])
price_to_predict['airconditioning'] = pd.Categorical(price_to_predict['airconditioning'], categories=['no', 'yes'])
price_to_predict['prefarea'] = pd.Categorical(price_to_predict['prefarea'], categories=['no', 'yes'])
price_to_predict['furnishingstatus'] = pd.Categorical(price_to_predict['furnishingstatus'], categories=['furnished', 'semi-furnished', 'unfurnished'])

#对分类变量引入虚拟变量。
price_to_predict = pd.get_dummies(price_to_predict, drop_first=True,
                                  columns=['mainroad', 'guestroom',
                                           'basement', 'hotwaterheating',
                                           'airconditioning','prefarea',
                                           'furnishingstatus'], dtype=int)
price_to_predict.head()
price_to_predict = price_to_predict.drop(['bedrooms', 'furnishingstatus_semi-furnished'], axis=1)

#调用线性回归模型的predict方法，获得预测价格。
predicted_value = model.predict(price_to_predict)
predicted_value


#线性回归模型预测的价格为： 5019251






















